import React from "react";
import { useNavigate } from "react-router-dom";

interface Props {
  to: string;
  text?: string;
}

const BackBtn: React.FC<Props> = ({ to, text }) => {
  const navigate = useNavigate();
  return (
    <button
      className="back-btn"
      onClick={() => navigate(to)}
      aria-label={text ?? "Back"}
    >
      <svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M15 18l-6-6 6-6" />
      </svg>
    </button>
  );
};

export default BackBtn;
