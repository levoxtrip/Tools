import React from "react";
import { Link } from "react-router-dom";
import { tools } from "../data/tools";
import CategoryIcon from "../component/CategoryIcon";

const CategoriesPage: React.FC = () => {
  const categoryCounts = tools.reduce<Record<string, number>>((acc, tool) => {
    acc[tool.category] = (acc[tool.category] ?? 0) + 1;
    return acc;
  }, {});

  const allCategories = Object.keys(categoryCounts);

  return (
    <div className="grid-2">
      {allCategories.map((category) => (
        <Link
          key={category}
          to={`/categories/${category}`}
          className="category-card"
        >
          <div className="category-card-icon">
            <CategoryIcon category={category} />
          </div>
          <h3 className="category-card-title">{category}</h3>
          <p className="category-card-meta">
            {categoryCounts[category]}{" "}
            {categoryCounts[category] === 1 ? "tool" : "tools"}
          </p>
        </Link>
      ))}
    </div>
  );
};

export default CategoriesPage;
