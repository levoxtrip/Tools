import React, { useState } from "react";
import { useParams } from "react-router-dom";
import { tools } from "../data/tools";
import { InformationData } from "../data/informations";
import BackBtn from "../component/BackBtn";
import InfoBtn from "../component/InfoBtn";

const ToolPage: React.FC = () => {
  const { toolId } = useParams<{ toolId: string }>();
  const tool = tools.find((t) => t.id === toolId);
  const [showInfo, setShowInfo] = useState<boolean>(false);

  if (!tool) {
    return (
      <div className="page">
        <BackBtn to="/categories" text="Back" />
        <h1>Tool not found</h1>
      </div>
    );
  }

  const info = InformationData[tool.information];

  return (
    <div className="page">
      <BackBtn to={`/categories/${tool.category}`} text="Back" />

      <article className="tool-card">
        {info && (
          <InfoBtn
            onToggle={() => setShowInfo((s) => !s)}
            showingInfo={showInfo}
          />
        )}

        {!showInfo && (
          <>
            <h1 className="tool-card-title">{tool.title}</h1>
            <p className="tool-card-body">{tool.description.trim()}</p>
          </>
        )}

        {showInfo && info && (
          <>
            <h1 className="tool-card-title">{info.title}</h1>
            <p className="tool-card-body">{info.content.trim()}</p>
          </>
        )}
      </article>
    </div>
  );
};

export default ToolPage;
