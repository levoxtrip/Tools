# Daily Tools — Restyled

A drop-in restyle of your existing app. The routes, the data files (`tools.ts`,
`informations.ts`), and the prop shapes are unchanged so this slots into your
project without breaking anything.

## What changed visually

1. **Home page** — A big black hero card ("Today's Tool") that picks a random
   tool from `tools.ts`. "Begin" navigates to that tool. "Try another →"
   re-rolls without leaving the page. Inspired by the Daily Check-In card.

2. **CategoriesPage** — White rounded cards in a 1/2/3-column responsive grid,
   each with an icon, the category name, and a tool count. Inspired by the
   bedtime stories layout.

3. **ToolsOverviewPage** — Horizontal swipeable carousel of cards.
   - Mobile: native scroll-snap, swipe with your thumb.
   - Desktop: arrow buttons appear on the sides and disable at the ends.
   - Each card shows icon, title, description preview, and an "Open" pill.

4. **ToolPage** — Cleaner white rounded card with a circular `i` button in the
   top-right. Toggling shows the info content. The `×` replaces `i` while info
   is showing so it's clear how to go back.

5. **BackBtn** — Round white button with an arrow icon (replaces the blue
   square). Same `to` / `text` props as before.

## File layout

```
src/
├── App.css                          ← restyled (Tailwind v4 + components)
├── App.tsx                          ← same routes, cleaner imports
├── component/
│   ├── BackBtn.tsx                  ← restyled
│   ├── InfoBtn.tsx                  ← restyled (renamed prop: onToggle)
│   ├── CategoryIcon.tsx             ← NEW: SVG icon per category
│   ├── DailyToolHero.tsx            ← NEW: black hero card
│   └── ToolsCarousel.tsx            ← NEW: swipeable carousel
├── pages/
│   ├── Home.tsx                     ← uses hero + categories
│   ├── CategoriesPage.tsx           ← grid of cards
│   ├── ToolsOverviewPage.tsx        ← uses carousel
│   ├── ToolPage.tsx                 ← restyled card + info toggle
│   └── NotFound.tsx                 ← restyled
├── data/
│   ├── ToolDataT.ts                 ← unchanged
│   ├── InformationDataT.ts          ← unchanged
│   ├── tools.ts                     ← keep your existing one
│   └── informations.ts              ← keep your existing one
└── utils/
    └── getRandomTool.ts             ← NEW: helper for the hero
```

## Drop-in steps

1. Replace the matching files in your project. Your `tools.ts`,
   `informations.ts`, `ToolDataT.ts`, and `InformationDataT.ts` stay exactly
   where they are — none of them need editing.
2. The `InfoBtn` prop renamed from `onToogleShowTool` to `onToggle` (typo fix)
   and now also takes `showingInfo: boolean` so it can swap `i` ↔ `×`.
3. No new dependencies. Everything still uses Tailwind v4 + react-router-dom.

## Mobile + desktop

- Hero card: stacks vertically, scales font-size at `md` breakpoint.
- Categories grid: 1 column on phone, 2 on tablet, 3 on desktop.
- Carousel: ~78% width cards on mobile (peek the next), fixed 320px on desktop.
- Buttons: 11×11 (44px) tap targets — meets iOS guidelines.
- All hover effects are paired with focus rings so keyboard users get feedback.
