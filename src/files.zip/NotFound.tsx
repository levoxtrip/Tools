import React from "react";
import BackBtn from "../component/BackBtn";

const NotFound: React.FC = () => {
  return (
    <div className="page">
      <BackBtn to="/" text="Back" />
      <header className="page-header">
        <h1>Lost.</h1>
        <p className="page-subtitle">
          That page doesn't exist. Head back home and pick a tool.
        </p>
      </header>
    </div>
  );
};

export default NotFound;
