import React from "react";
import DailyToolHero from "../component/DailyToolHero";
import CategoriesPage from "./CategoriesPage";

const Home: React.FC = () => {
  return (
    <div className="page">
      <header className="page-header">
        <h1>Daily Tools To Strive</h1>
        <p className="page-subtitle">
          Small practices to master your day.
        </p>
      </header>

      <DailyToolHero />

      <section>
        <h2 className="mb-5">Categories</h2>
        <CategoriesPage />
      </section>
    </div>
  );
};

export default Home;
