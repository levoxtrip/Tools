import React from "react";
import { useParams } from "react-router-dom";
import { tools } from "../data/tools";
import BackBtn from "../component/BackBtn";
import ToolsCarousel from "../component/ToolsCarousel";

const ToolsOverviewPage: React.FC = () => {
  const { toolsOverview } = useParams<{ toolsOverview: string }>();
  const filtered = tools.filter((tool) => tool.category === toolsOverview);

  return (
    <div className="page">
      <BackBtn to="/categories" text="Back" />

      <header className="page-header">
        <h1>{toolsOverview}</h1>
        <p className="page-subtitle">
          {filtered.length} {filtered.length === 1 ? "tool" : "tools"} to
          explore. Swipe through and pick one.
        </p>
      </header>

      <ToolsCarousel tools={filtered} categorySlug={toolsOverview ?? ""} />
    </div>
  );
};

export default ToolsOverviewPage;
